vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|19 Apr 2007 01:52:32 -0000
vti_extenderversion:SR|12.0.0.6211
vti_backlinkinfo:VX|utilities/dmbuilderde/help/index.html
