<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Sample</title>
<link type="text/css" href="../../styles.css">
</head>

<body><!-- DHTML Menu Builder Loader Code START -->
<div id=DMBRI style="position:absolute;">
<img src="menus/dmb_i.gif" name=DMBImgFiles width="1" height="1" border="0" alt="">
<img src="menus/dmb_m.gif" name=DMBJSCode width="1" height="1" border="0" alt="">
</div>
  <script language="JavaScript" type="text/javascript">
var rimPath=null;var rjsPath=null;var rPath2Root=null;function InitRelCode(){var iImg;var jImg;var tObj;if(!document.layers){iImg=document.images['DMBImgFiles'];jImg=document.images['DMBJSCode'];tObj=jImg;}else{tObj=document.layers['DMBRI'];if(tObj){iImg=tObj.document.images['DMBImgFiles'];jImg=tObj.document.images['DMBJSCode'];}}if(!tObj){window.setTimeout("InitRelCode()",700);return false;}rimPath=_gp(iImg.src);rjsPath=_gp(jImg.src);rPath2Root=rjsPath+"../";return true;}function _purl(u){return xrep(xrep(u,"%%REP%%",rPath2Root),"\\","/");}function _fip(img){if(img.src.indexOf("%%REL%%")!=-1) img.src=rimPath+img.src.split("%%REL%%")[1];return img.src;}function _gp(p){return p.substr(0,p.lastIndexOf("/")+1);}function xrep(s,f,n){if(s) s=s.split(f).join(n);return s;}InitRelCode();
</script>
  <script language="JavaScript" type="text/javascript">
function LoadMenus() {if(!rjsPath){window.setTimeout("LoadMenus()", 10);return false;}var navVer = navigator.appVersion;
if(navVer.substr(0,3) >= 4)
if((navigator.appName=="Netscape") && (parseInt(navigator.appVersion)==4)) {
;} else {
document.write('<' + 'script language="JavaScript" type="text/javascript" src="' + rjsPath + 'iemenu.js"><\/script\>');
}return true;}LoadMenus();</script>
<!-- DHTML Menu Builder Loader Code END -->
<p>&nbsp;</p>
<p>&nbsp;</p>
<form action="index.php" method="post">
	User Name<br>
	<input type="text" value="" name="UserName"> <input type="submit" value="Login">
</form>

<script language="javascript" type="text/javascript">
	dmbAPI_Init();
	
	// Since the DynAPI does not support items that have been disabled form within DHTML Menu Builder,
	//	we need to disable them here, using the API.
	dmbAPI_setItemState(dmbAPI_getItemByCaption("UserName"), false);
	dmbAPI_setItemState(dmbAPI_getItemByCaption("|"), false);
	
	var n;
	// Because we are going to be working with the UserName toolbar item it is a good idea
  	// to store its id in a variable so, every time we need to reference it we can just
	// use the value in the variable.
	var c = dmbAPI_getItemByCaption("UserName");
	
// So, let's see if the server-side variable $UserName contains any data
<? if(!isset($UserName) || ($UserName=="")) { ?>
	// The variable contained no data, which means that no one has logged in,
	// so we're going to disable the Utilities menu.</font>
	var n = dmbAPI_getItemByCaption("Utilities");
	dmbAPI_removeTBItem(n);
<? } ?>

// Let's check now if the user &quot;root&quot; has logged in
<? if($UserName != "root") { ?>
		// The user name variable does not match "root" so the root user is not logged in.
		// In this case, we need to disable the "DHTML Menu Builder" menu. 
		var n = dmbAPI_getItemByCaption("DHTML Menu Builder");
		dmbAPI_setItemState(n, false);
		dmbAPI_setColor(n, "#C8C8C8");
<? } ?>

	// Finally, let's display the current;y logged in user name
	dmbAPI_setCaption(c, "<? echo (isset($UserName) && $UserName!="")?$UserName:"(not logged in)"; ?>");
</script>

<hr noshade color="#A8A8A8" size="1">

<p>This sample provides a simple demonstration of how you could handle the activation and removal of menu items based on some server side variable value, such as a variable that handles the user name of the logged in user.</p>

<p>Here's how the sample works:</p>
<ul>
  <li>When the page is first accessed the code completely removes the "Utilities" menu item from the toolbar and displays "not logged in" in the first item of the toolbar.</li>
  <li>If you enter a name (it can be anything since the sample doesn't really
    check the entered name) the name will be displayed in the first menu
    item of the toolbar, the "Utilities" menu will become visible but the "DHTML
    Menu Builder" submenu will be disabled. </li>
  <li>Finally, if you login using &quot;root&quot; (just enter root in the textbox and click Login), the &quot;Utilities&quot; menu will become visible and the &quot;DHTML Menu Builder&quot; item will become enabled.</li>
</ul>
<p>Here's the code that does the magic:</p>
<table border="1" bgcolor="#FFFFCC" style="border-collapse:collapse;" cellspacing="0" cellpadding="4">
<tr><td style="font-family:'Courier New';font-size:12px">
  <p>&lt;script language=&quot;javascript&quot; type=&quot;text/javascript&quot;&gt;<br>
  <a href="/utilities/dmbuilderde/help/functions/init/dmbAPI_Init.htm" target="_blank">dmbAPI_Init();</a><br>
  <br><font color="#008000">
  // Since the DynAPI does not support items that have been disabled form within
  DHTML Menu Builder,<br>// we need to disable them here, using the API.</font><br>
<a href="../../functions/events/dmbAPI_setItemState.htm">dmbAPI_setItemState</a>(<a href="../../functions/helper/dmbAPI_getItemByCaption.htm">dmbAPI_getItemByCaption</a>(&quot;UserName&quot;),
false);<br>
<a href="../../functions/events/dmbAPI_setItemState.htm">dmbAPI_setItemState</a>(<a href="../../functions/helper/dmbAPI_getItemByCaption.htm">dmbAPI_getItemByCaption</a>(&quot;|&quot;),
false);<br>
  <br>
  var n;<br>
  <font color="#008000">// Because we are going to be working with the UserName
  toolbar item it is a good idea<br>
  // to store its id in a variable so, every time we need to reference it we
  can just<br>
  // use the value in the variable.  </font><br>
    var c = <a href="../../functions/helper/dmbAPI_getItemByCaption.htm">dmbAPI_getItemByCaption</a>(&quot;UserName&quot;);<br>
    <br>
    <font color="#008000">// So, let's see if the server-side variable $UserName
    contains any data</font><br>
&lt;? if(!isset($UserName) || ($UserName==&quot;&quot;)) { ?&gt;<br>
<font color="#008000">&nbsp;&nbsp;// The variable contained no data, which means
that no one has logged in, <br>
&nbsp;&nbsp;// so we're going to disable the Utilities menu. </font><br>
&nbsp;&nbsp;n = <a href="/utilities/dmbuilderde/help/functions/helper/dmbAPI_getItemByCaption.htm" target="_blank">dmbAPI_getItemByCaption</a>(&quot;Utilities&quot;);<br>
&nbsp;&nbsp;<a href="/utilities/dmbuilderde/help/functions/addrem/dmbAPI_removeTBItem.htm" target="_blank">dmbAPI_removeTBItem</a>(n);<br>
&lt;? } ?&gt;<br>
<br>
<font color="#008000">// Let's check now if the user &quot;root&quot; has logged in</font><br>
&lt;? if($UserName != &quot;root&quot;) { ?&gt;<br>
<font color="#008000">&nbsp;&nbsp;// The user name variable does not match &quot;root&quot; so the root user is not logged in.<br>
&nbsp;&nbsp;// </font><font color="#008000">In this case, we need to disable the  &quot;DHTML Menu Builder&quot; menu. </font><br>
&nbsp;&nbsp;n = <a href="/utilities/dmbuilderde/help/functions/helper/dmbAPI_getItemByCaption.htm" target="_blank">dmbAPI_getItemByCaption</a>(&quot;DHTML
    Menu Builder&quot;);<br>
&nbsp;&nbsp;<a href="/utilities/dmbuilderde/help/functions/events/dmbAPI_setItemState.htm" target="_blank">dmbAPI_setItemState</a>(n,
    false);<br>
&nbsp;&nbsp;<a href="/utilities/dmbuilderde/help/functions/setstyles/dmbAPI_setColor.htm" target="_blank">dmbAPI_setColor</a>(n, &quot;#C8C8C8&quot;);<br>
&lt;? } ?&gt;<br>
  <br>
  <font color="#008000">// Finally, let's display the current;y logged in user
    name </font><br>
    n = <a href="/utilities/dmbuilderde/help/functions/helper/dmbAPI_getItemByCaption.htm" target="_blank">dmbAPI_getItemByCaption</a>(&quot;UserName&quot;);<br>
    <a href="/utilities/dmbuilderde/help/functions/setstyles/dmbAPI_setCaption.htm" target="_blank">dmbAPI_setCaption</a>(n, &quot;&lt;?
    echo (isset($UserName) &amp;&amp; $UserName!=&quot;&quot;)?$UserName:&quot;(not logged in)&quot;; ?&gt;&quot;);<br>
&lt;/script&gt;    </p>
  </td></tr>
</table>
</body>
</html>
