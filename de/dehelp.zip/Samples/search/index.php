<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link media="all" type="text/css" href="/styles.css" rel="stylesheet">
<title>Search</title>
</head>

<body><!-- DHTML Menu Builder Loader Code START -->
<div id=DMBRI style="position:absolute;">
<img src="menus/dmb_i.gif" name="DMBImgFiles" width="1" height="1" border="0" alt="">
<img src="menus/dmb_m.gif" name="DMBJSCode" width="1" height="1" border="0" alt="">
</div>
<script language="JavaScript" type="text/javascript">
var rimPath=null;var rjsPath=null;var rPath2Root=null;function InitRelCode(){var iImg;var jImg;var tObj;if(!document.layers){iImg=document.images['DMBImgFiles'];jImg=document.images['DMBJSCode'];tObj=jImg;}else{tObj=document.layers['DMBRI'];if(tObj){iImg=tObj.document.images['DMBImgFiles'];jImg=tObj.document.images['DMBJSCode'];}}if(!tObj){window.setTimeout("InitRelCode()",700);return false;}rimPath=_gp(iImg.src);rjsPath=_gp(jImg.src);rPath2Root=rjsPath+"../";return true;}function _purl(u){return xrep(xrep(u,"%%REP%%",rPath2Root),"\\","/");}function _fip(img){if(img.src.indexOf("%%REL%%")!=-1) img.src=rimPath+img.src.split("%%REL%%")[1];return img.src;}function _gp(p){return p.substr(0,p.lastIndexOf("/")+1);}function xrep(s,f,n){if(s) s=s.split(f).join(n);return s;}InitRelCode();
function LoadMenus() {if(!rjsPath){window.setTimeout("LoadMenus()", 10);return false;}var navVer = navigator.appVersion;
if(navVer.substr(0,3) >= 4)
if((navigator.appName=="Netscape") && (parseInt(navigator.appVersion)==4)) {
document.write('<' + 'script language="JavaScript" type="text/javascript" src="' + rjsPath + 'nsxpmenu.js"><\/script\>');
} else {
document.write('<' + 'script language="JavaScript" type="text/javascript" src="' + rjsPath + 'iexpmenu.js"><\/script\>');
}return true;}LoadMenus();</script>
<!-- DHTML Menu Builder Loader Code END -->

<script language="JavaScrip" type="text/javascript">
	// This sample will not work under Opera or Safari due to problems with these browsers and the
	//	XMLHTTP object.
	var validBrowser = (!OP&&!KQ);
	var xmlhttp = false;
	/*@cc_on @*/
	/*@if (@_jscript_version >= 5)
	try {
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	} catch (e) {
		try {
			xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		} catch (E) {
			xmlhttp = false;
		}
	}
	@end @*/
	if (!xmlhttp && typeof XMLHttpRequest!='undefined') xmlhttp = new XMLHttpRequest();

	// Array to hold the caption of the search results
	var cap;
	
	// Query timer handler
	var qsH = 0;
	
	// Auto close timer handler
	var ahH = 0;
	
	// URL that will receive our query.
	//	Since the query is sent to Google, Mozilla-based browsers will fail to work
	//	if we use www.google.com as the target URL due to the cross-domain security
	//	imposed in the browser. So, requests will be sent to this same web server and
	//	will be parsed through a simple PHP-based proxy.
	//	The proxy we're using is called Otto. For more information visit: http://sourceforge.net/projects/php-proxy/
	//var gURL = (SM?"/utilities/dmbuilderde/help/Samples/search/otto.php?file=":"http://www.google.com/complete/search?hl=en&js=true&qu=");
	var gURL = "/utilities/dmbuilderde/help/Samples/search/otto.php?file=";
	
	// This variable will hold the index of the menu item used to display
	//	the information about the search status. This is the first item
	//	under the "Search Results" group.
	var nfoItem;
	
	// This variable will hold a reference to the textbox
	var txt;
	
	// This variable serves as a cache and holds the last performed query.
	//	The variable will be used to avoid repetitive calls to Google with the same query.
	var lastQry;
	
	// This is the status variable and is used to determine if there's a search in progress.
	var IsReady = true;
	
	// This is the HTML code that will be used to display the search textbox on the toolbar
	var txtBoxHTML = '&nbsp; <input id="searchBox" type="text" size="20" onKeyUp="queueSearch(this)" autocomplete="off" style="font-family:Verdana;font-size:11px;">';
	
	// This function alerts the user if his/her browser is not supported
	function showNVB() {
		alert("Your browser is not supported!\n\nAt this moment this sample will only work under Internet Explorer for Windows");
	}
	
	// This function initializes the interface and various variables
	function Init() {
		// As always, the first thing to do is to initialize the DynAPI
		dmbAPI_Init();
		
		// Apply the HTML code for the textbox to the toolbar item
		dmbAPI_setCaption(dmbAPI_getItemByCaption("SearchTextBox"), txtBoxHTML);
					
		// Obtain a reference to the menu item used to display the search status
		nfoItem = dmbAPI_getItemByCaption("info");
		
		// Set the search status menu item to its default
		resetInfoCmdCaption();
		
		// Finally, if the browser is not supported... alert the user
		if(!validBrowser) showNVB();
	}
	
	// This function will place the search request in queue.
	// 	This will allow us to start the search as soon as the user has stopped typing after
	//	about 700 milliseconds.
	function queueSearch(sq) {
		if(validBrowser) {
			if(sq.value!=lastQry) {
				txt = sq;
				lastQry = txt.value;
				if(qsH != 0) window.clearTimeout(qsH);
				qsH = window.setTimeout("prepareSearch()", 700);
			}
		} else
			showNVB();
	}
	
	// This function is called when the user has finished typing the search query
	function prepareSearch() {
		if(txt.value != "") {
			if(!IsReady) resetSearchRes(false);
			dmbAPI_setCaption(nfoItem, "Searching...");
			window.setTimeout("doSearch()", 50);
		}
	}
	
	// Finally! this is the function that does the magic...
	function doSearch() {
		// Initiate the "GET" operation
		xmlhttp.open("GET", gURL + txt.value, true);
		// Define the function that will handle the results
		xmlhttp.onreadystatechange = function() {
			if(xmlhttp.readyState==4) {
				var r = xmlhttp.responseText;
				if(r.indexOf("window.google.ac.Suggest_apply")==-1) {
					dspError("An error has occured...<br>Google didn't return a valid result");
					//alert(r);
				} else {
					r = xrep(r, "window.google.ac.Suggest_apply", "sendRPCDone");
					eval(r);
				}
			}
		}
		xmlhttp.send(null);
	}
	
	// This function will be called when something has gone wrong and will display
	//	the error or warning message inside the search results group
	function dspError(msg) {
		cap = new Array();
		cap[1] = dmbAPI_addCommand("grpSearchBox", msg);
		dmbAPI_setColor(cap[1], "#FF0000", "", "#FF0000");
		dmbAPI_setItemState(cap[1], false);
		cap[2] = "";
	}
	
	// This is the function that handles the response from Google
	//	When Google returns its suggestions it does by passing several arrays to the function.
	//	So, all we have to do is to parse those arrays and call the dmbAPI_addCommand() function
	//	to populate the search results group.
	function sendRPCDone() {
		cap = arguments[2];
		var c;
		var n = 0;
		
		if(cap.length < 3) {
			dspError("No results!");
		} else {
			for(var i = 1; i < cap.length; i += 2) {
				n = Math.max(cap[i].length + cap[i+1].length, n);
				c = dmbAPI_addCommand("grpSearchBox", '<table cellpadding=0 cellspacing=0 border=0 width=90%><tr><td align=left nowrap>'+cap[i]+'</td><td align=right nowrap style="color:#008000">'+cap[i+1]+'</td></tr></table>');
				dmbAPI_setOnClick(c, "http://www.google.com/search?sourceid=mozclient&ie=utf-8&oe=utf-8&q=" + cap[i], "_blank");
				cap[i] = c;
			}
			dmbAPI_setGroupWidth("grpSearchBox", n*8);
			
			/*
			// For some reason, which I still have to figure out, Mozila will not
			//	properly resize the caption part of menu items containing HTML tags so... we must help it ;)
			if(SM)
				for(var i = 0; i < cap.length; i++)
					_getobj("N" + cap[i]).getElementsByTagName("DIV")[0].style.width = (n+3)*8 + "px";
			*/
		}
		
		dmbAPI_setCaption(nfoItem, "Search Results:");
		
		// Uncomment this line to re-set the search results group when its hidden.
		//ahH = window.setInterval("if(nOM==0) resetSearchRes(true)", 10);
		IsReady = false;
	}
	
	// This function will remove all the commands from the previously executed search query
	//	leaving the group ready to accept new commands
	function resetSearchRes(resetTextBox) {
		window.clearInterval(ahH);
		for(var i = cap.length - 2; i > 0; i -= 2)	dmbAPI_removeCommand(cap[i]);
		resetInfoCmdCaption();
		if(resetTextBox) txt.value = "";
		IsReady = true;
	}
	
	// This function re-sets the command used to display the status of the search query
	//	to its default value.
	function resetInfoCmdCaption() {
		dmbAPI_setCaption(nfoItem, "Type your search query in the textbox...");
	}

	Init();
</script>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div class="sectTitle">Populating a menu using the XMLHTTP request object</div>
<small>Updated 4/Jan/2008</small>
<p>This sample demonstrates how to populate a menu created with <a href="http://software.xfx.net/utilities/dmbuilderde/" target="_blank">DHTML
    Menu Builder &lt;developer's edition&gt; </a>  from information retrieved
    through the XMLHTTP request object.<br>
  Although most of the modern browsers support this object, this sample (for
    reasons that escape the purposes of the sample) will only work under Internet
    Explorer 6.0 and most Mozilla-based browsers (such as FireFox).</p>
<p>To use the search feature simply move the mouse over the text box, click it
  and start typing your query.<br>
  The search will begin as soon as you stop typing. Then, when Google reponse
  is received the menu will be populated with the search results. At this point
  you can either modify your query, select one of the results with your mouse
  or move the mouse away to close the menu.</p>
<p>The way the search results are retrieved from Google is very similar to <a href="http://www.google.com/webhp?complete=1&hl=en" target="_blank">Google's
  Suggest</a> service.<br>
  For more information about the XMLHTTP object and the way Google's Suggest
  works I highly recommend you that you visit <a href="http://serversideguy.blogspot.com/2004/12/google-suggest-dissected.html" target="_blank">Chris
  Justus's blog</a>.</p>
<p>Then, when Google returns the search results we simply use standard <a href="http://software.xfx.net/utilities/dmbuilderde/" target="_blank">DynAPI
  functions from DHTML Menu Builder &lt;developers' edition&gt;</a> to populate
  the Search menu.</p>
<p>More information and a detailed tutorial about this sample will be provided
  as soon as DHTML Menu Builder 4.9.016 is released.</p>
<div class="sectTitle">History</div>
<p>Version 0.3 (4/Jan/2008) </p>
<ul>
  <li>Added support for the new format used by Google's suggest response data<a href="http://sourceforge.net/projects/php-proxy/" target="_blank"></a></li>
</ul>
<p>Version 0.2 (18/Mar/2005) </p>
<ul>
  <li>Added support for Mozilla-based browsers through the use of a <a href="http://sourceforge.net/projects/php-proxy/" target="_blank">PHP-based
    proxy</a></li>
  <li>Added support to handle errors and notify the user </li>
  <li>Implemented an automatic resize function to resize the toolbar so the textbox
    is properly fitted under all supported browsers/platforms</li>
  <li>The javascript code has been documented (check the source of this page
    to see the javascript code)</li>
</ul>
<p>Version 0.1 (15/Mar/2005) </p>
<blockquote>
  <p>First public release </p>
</blockquote>
</body>
</html>
