<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>DHTML ComboBox</title>
<style type="text/css">
<!--
.style1 {
	font-family: Tahoma;
	font-size: 12px;
}
-->
</style>
</head>

<body topmargin="0" leftmargin="10"><!-- DHTML Menu Builder Loader Code START -->
<div id=DMBRI style="position:absolute;">
<img src="menus/dmb_i.gif" name=DMBImgFiles width="1" height="1" border="0" alt="">
<img src="menus/dmb_m.gif" name=DMBJSCode width="1" height="1" border="0" alt="">
</div>
<script language="JavaScript" type="text/javascript">
var rimPath=null;var rjsPath=null;var rPath2Root=null;function InitRelCode(){var iImg;var jImg;var tObj;if(!document.layers){iImg=document.images['DMBImgFiles'];jImg=document.images['DMBJSCode'];tObj=jImg;}else{tObj=document.layers['DMBRI'];if(tObj){iImg=tObj.document.images['DMBImgFiles'];jImg=tObj.document.images['DMBJSCode'];}}if(!tObj){window.setTimeout("InitRelCode()",700);return false;}rimPath=_gp(iImg.src);rjsPath=_gp(jImg.src);rPath2Root=rjsPath+"../";return true;}function _purl(u){return xrep(xrep(u,"%%REP%%",rPath2Root),"\\","/");}function _fip(img){if(img.src.indexOf("%%REL%%")!=-1) img.src=rimPath+img.src.split("%%REL%%")[1];return img.src;}function _gp(p){return p.substr(0,p.lastIndexOf("/")+1);}function xrep(s,f,n){if(s) s=s.split(f).join(n);return s;}InitRelCode();
</script>
<script language="JavaScript" type="text/javascript">
function LoadMenus() {if(!rjsPath){window.setTimeout("LoadMenus()", 10);return false;}var navVer = navigator.appVersion;
if(navVer.substr(0,3) >= 4)
if((navigator.appName=="Netscape") && (parseInt(navigator.appVersion)==4)) {
document.write('<' + 'script language="JavaScript" type="text/javascript" src="' + rjsPath + 'nsmenu.js"><\/script\>');
} else {
document.write('<' + 'script language="JavaScript" type="text/javascript" src="' + rjsPath + 'iemenu.js"><\/script\>');
}return true;}LoadMenus();</script>
<!-- DHTML Menu Builder Loader Code END -->

<script language="JavaScript">
	var nc;
	var cmbSelected = -1;
	var cmbOp = new Array();
	var cmbOpI = new Array();
	var idx = 0;
	var tbi;
	
	dmbAPI_Init();
	dmbAPI_addGroup("Products");
	tbi = dmbAPI_getItemByCaption("selItem");
	dmbAPI_setOnClick(tbi, "Products", '', true, 0);
	
<?
	mysql_connect("localhost","root","plank-23");
	mysql_select_db("xfx_soft_data");
	
	$q = mysql_query("select * from products order by DispOrder;");
	$t = mysql_num_rows($q);
	
	$i = 0;
	while($i < $t) {
?>
		cmbOp[idx] = "<? echo mysql_result($q, $i, "Name"); ?>";
		cmbOpI[idx] = "<? echo mysql_result($q, $i, "Icon"); ?>";
		if(cmbOpI[idx]=="") cmbOpI[idx] = "blank.gif";
		nc = dmbAPI_addCommand("Products", cmbOp[idx]);
		dmbAPI_setImageLeftNormal(nc, "/menu/images/" + cmbOpI[idx], 16, 16);
		dmbAPI_setOnClick(nc, "javascript:cmbSelect(" + idx + ")");
		idx++;
<?
		$i++;
	}
?>
	
	function cmbSelect(n) {
		var j;
		for(var i=0; i<idx; i++) {
			j = dmbAPI_getItemByCaption(cmbOp[i], mFrame, "Products");
			if(i==n)
				dmbAPI_setColor(j, "#FFFFFF", "#0000FF", "#FFFFFF", "#0000FF");
			else
				dmbAPI_setColor(j, "#000000", "#FFFFFF", "#FFFFFF", "#0000FF");
		}
		dmbAPI_setCaption(tbi, cmbOp[n], true);
		dmbAPI_setImageLeftNormal(tbi, "/menu/images/" + cmbOpI[n]);
		cmbSelected = n;
	}
	
	function setGroupSize() {
		if(!tbO[1])
			window.setTimeout("setGroupSize()", 100);
		else {
			dmbAPI_setGroupWidth("Products", 200);
			// Comment this line to allow the combo box to resize itself based on its contents
			dmbAPI_setTBWidth(1, 200);
		}
	}
	
	setGroupSize();
	cmbSelect(0);
</script>
<br>
<p class="style1">This sample demonstrates how to use the DynAPI to create a
  100% DHTML-based ComboBox with images.</p>
<p class="style1">&nbsp;</p>
<p class="style1">&nbsp;</p>
<p class="style1">Here's
    how this project works:</p>
<ul>
  <li class="style1">The .dmb project is very simple: it only contains a toolbar, a toolbar item
    and the DynAPI template.</li>
  <li class="style1">The colors have been adjusted so the menu items resemble the standard Windows
    3.1/Windows 95 comboboxes: white, black and blue.</li>
  <li class="style1">The rest is all DynAPI and a simple function to change the selection. Here's
  the source code:</li>
</ul>
<blockquote>
<table border="1" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="80%" id="table1" bgcolor="#FFFFCC"><tr>
    <td width="100%" nowrap><p><font face="Courier New" size="1"> &lt;script language=&quot;JavaScript&quot;&gt;<br>
&nbsp;&nbsp;&nbsp; var nc;<br>
&nbsp;&nbsp;&nbsp; var cmbSelected = -1;<br>
&nbsp;&nbsp;&nbsp; var cmbOp = new Array();<br>
 &nbsp;&nbsp;&nbsp; var cmbOpI = new Array();    </font><font face="Courier New" size="1"><br>
&nbsp;&nbsp;&nbsp; var idx = 0;<br>
&nbsp;&nbsp;&nbsp; var tbi;<br>
    <br>
&nbsp;&nbsp;&nbsp; <a href="../../functions/init/dmbAPI_Init.htm" target="_blank">dmbAPI_Init</a>();<br>
&nbsp;&nbsp;&nbsp; <a href="../../functions/addrem/dmbAPI_addGroup.htm" target="_blank">dmbAPI_addGroup</a>(&quot;Products&quot;);<br>
&nbsp;&nbsp;&nbsp; tbi = <a href="../../functions/helper/dmbAPI_getItemByCaption.htm" target="_blank">dmbAPI_getItemByCaption</a>(&quot;selItem&quot;);<br>
&nbsp;&nbsp;&nbsp; <a href="../../functions/events/dmbAPI_setOnClick.htm" target="_blank">dmbAPI_setOnClick</a>(tbi, &quot;Products&quot;,
  '', true, 0);<br>
    <br>
&lt;?<br>
&nbsp;&nbsp;&nbsp; mysql_connect(&quot;localhost&quot;,&quot;db_user&quot;,&quot;db_password&quot;);<br>
&nbsp;&nbsp;&nbsp; mysql_select_db(&quot;xfx_soft_data&quot;);<br>
    <br>
&nbsp;&nbsp;&nbsp; $q = mysql_query(&quot;select * from products;&quot;);<br>
&nbsp;&nbsp;&nbsp; $t = mysql_num_rows($q);<br>
    <br>
&nbsp;&nbsp;&nbsp; $i = 0;<br>
&nbsp;&nbsp;&nbsp; while($i &lt; $t) {<br>
?&gt;<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; cmbOp[idx] = &quot;&lt;? echo mysql_result($q, $i, &quot;Name&quot;); ?&gt;&quot;;<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; cmbOpI[idx] = &quot;&lt;? echo mysql_result($q, $i, &quot;Icon&quot;); ?&gt;&quot;;<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; if(cmbOpI[idx]==&quot;&quot;) cmbOpI[idx] = &quot;blank.gif&quot;;<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; nc = <a href="../../functions/addrem/dmbAPI_addCommand.htm" target="_blank">dmbAPI_addCommand</a>(&quot;Products&quot;,
    cmbOp[idx]);<br>
    &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; <a href="../../functions/setstyles/dmbAPI_setImageLeftNormal.htm" target="_blank">dmbAPI_setImageLeftNormal</a>(nc, &quot;/menu/images/&quot; + cmbOpI[idx], 16,
    16); </font><font face="Courier New" size="1"><br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; <a href="../../functions/events/dmbAPI_setOnClick.htm">dmbAPI_setOnClick</a>(nc, &quot;javascript:cmbSelect(&quot; + idx + &quot;)&quot;);<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; idx++;<br>
&lt;?<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; $i++;<br>
&nbsp;&nbsp;&nbsp; }<br>
?&gt;<br>
      <br>
&nbsp;&nbsp;&nbsp; function cmbSelect(n) {<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; var j;<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; for(var i=0; i&lt;idx; i++) {<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; j = <a href="../../functions/helper/dmbAPI_getItemByCaption.htm" target="_blank">dmbAPI_getItemByCaption</a>(cmbOp[i],
    mFrame, &quot;Products&quot;);<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; if(i==n)<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; <a href="../../functions/setstyles/dmbAPI_setColor.htm" target="_blank">dmbAPI_setColor</a>(j, &quot;#FFFFFF&quot;, &quot;#0000FF&quot;, &quot;#FFFFFF&quot;, &quot;#0000FF&quot;);<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; else<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; <a href="../../functions/setstyles/dmbAPI_setColor.htm" target="_blank">dmbAPI_setColor</a>(j, &quot;#000000&quot;, &quot;#FFFFFF&quot;, &quot;#FFFFFF&quot;, &quot;#0000FF&quot;);<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; }<br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; <a href="../../functions/setstyles/dmbAPI_setCaption.htm" target="_blank">dmbAPI_setCaption</a>(tbi,
  cmbOp[n]);<br>
  &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; <a href="../../functions/setstyles/dmbAPI_setImageLeftNormal.htm" target="_blank">dmbAPI_setImageLeftNormal</a>(tbi, &quot;/menu/images/&quot; + cmbOpI[n]);    </font><font face="Courier New" size="1"><br>
&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; cmbSelected = n;<br>
&nbsp;&nbsp;&nbsp; }<br>
&nbsp;&nbsp;&nbsp; cmbSelect(0);<br>
&lt;/script&gt;</font></p>
      </td>
</tr></table>
</blockquote>
<p>&nbsp;</p>
</body>
</html>
