<?
// Copyright (C) Scott Atkins 2002 <atkinssc@engr.orst.edu>
// This is protected by GPL, see the README.
// Edit these lines
$server="www.google.com/complete/search?hl=en&js=true&qu=";
$name="/utilities/dmbuilderde/help/Samples/search/";

// Do not edit
require("ottoscript.php");
?>
