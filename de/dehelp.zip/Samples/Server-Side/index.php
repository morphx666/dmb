<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Simple Sample</title>
</head>
<body><div id=DMBRI style="position:absolute;"><img src="menus/dmb_i.gif" name=DMBImgFiles border="0" alt=""> <img src="menus/dmb_m.gif" name=DMBJSCode border="0" alt=""> </div><script language="JavaScript" type="text/javascript">
var rimPath=null;var rjsPath=null;var rPath2Root=null;function InitRelCode(){var iImg;var jImg;var tObj;if(!document.layers){iImg=document.images['DMBImgFiles'];jImg=document.images['DMBJSCode'];tObj=jImg;}else{tObj=document.layers['DMBRI'];if(tObj){iImg=tObj.document.images['DMBImgFiles'];jImg=tObj.document.images['DMBJSCode'];}}if(!tObj){window.setTimeout("InitRelCode()",700);return false;}rimPath=_gp(iImg.src);rjsPath=_gp(jImg.src);rPath2Root=rjsPath+"../";return true;}function _purl(u){return xrep(xrep(u,"%%REP%%",rPath2Root),"\\","/");}function _fip(img){if(img.src.indexOf("%%REL%%")!=-1) img.src=rimPath+img.src.split("%%REL%%")[1];return img.src;}function _gp(p){return p.substr(0,p.lastIndexOf("/")+1);}function FixImages(){var h=null;var f=new Function("h","if(h)for(var i=0;i<h.length;i++)h[i]=xrep(h[i],'%%REL%%',rimPath);");f(hS);f(hshS);}function xrep(s,f,n){if(s) s=s.split(f).join(n);return s;}InitRelCode();
</script>
<script language="JavaScript" type="text/javascript">
function LoadMenus() {if(!rjsPath){window.setTimeout("LoadMenus()", 10);return false;}var navVer = navigator.appVersion;
if(navVer.substr(0,3) >= 4)
if((navigator.appName=="Netscape") && (parseInt(navigator.appVersion)==4)) {
document.write('<' + 'script language="JavaScript" type="text/javascript" src="' + rjsPath + 'nsmenu.js"><\/script\>');
} else {
document.write('<' + 'script language="JavaScript" type="text/javascript" src="' + rjsPath + 'iemenu.js"><\/script\>');
}return true;}LoadMenus();</script>
<script language="JavaScript">
	var nc;
	
	dmbAPI_Init();	
<?	
	mysql_connect("localhost","root","plank-23");
	mysql_select_db("dmbwebs");
	
	$q = mysql_query("select * from webs order by rand() limit 20;");
	$t = mysql_num_rows($q);

	$i = 0;
	while($i < $t) {
		
		$wname = mysql_result($q, $i, "Name");
		$url = mysql_result($q, $i, "URL");
		
		$wname = wordwrap($wname, 40, "<br>");
		
		echo "nc=dmbAPI_addCommand('Group001', '".addslashes($wname)."', ".($i<$t-1?"true":"false").");\n";		
		echo "dmbAPI_setOnClick(nc, '$url', '_blank', false);\n";
		
		$i++;
	}	
	mysql_close();
?>

</script>
<p><b><font face="Tahoma" size="2">Using Server Side Code to use the DynAPI</font></b></p><p><font face="Tahoma" size="2">Because the DynAPI is a set of javascript-based functions it works on the client side, that is, when the browser parses the javascript code. So in order to use server-side code to control the menus programmatically we need to generate function calls to the DynAPI using server-side code.</font></p>
<p><font size="2" face="Tahoma">Also notice that the menus will display scroll
    buttons if the menu is too large for the browser's window.<br>
    This is because we enabled the &quot;Global In-Group Scrolling&quot; option under File-&gt;Project
    Properties-&gt;Global Settings-&gt;Extended Features </font></p>
<p><font face="Tahoma" size="2">The sample below uses PHP and MySQL to add commands to an empty group from information on a database.</font></p>
<div align="center"><center><table border="1" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="80%" id="AutoNumber3" bgcolor="#FFFFCC"><tr><td width="100%" nowrap><font face="Courier New" size="1">&lt;script language=&quot;JavaScript&quot;&gt;<br>&nbsp;&nbsp;&nbsp; var nc;<br><br>&nbsp;&nbsp;&nbsp; <span style="color:#008000">// First of all we need to initialize the DynAPI</span><br>&nbsp;&nbsp;&nbsp; <a href="../../functions/init/dmbAPI_Init.htm">dmbAPI_Init</a>();<br>
<br>&nbsp;&nbsp;&nbsp; &lt;?<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#008000">// Connect to the MySQL server</span><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; mysql_connect(&quot;localhost&quot;,&quot;db_user&quot;,&quot;db_password&quot;);<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; mysql_select_db(&quot;dmbwebs&quot;);<br><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#008000">// Get 10 random entries from the database</span> <br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $q = mysql_query(&quot;select * from webs order by rand() limit 10;&quot;);<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $t = mysql_num_rows($q);<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $i = 0;<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; while($i &lt; $t) {<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#008000">// Get the name and URL of the web site</span><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $wname = mysql_result($q, $i, &quot;Name&quot;);<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $url = mysql_result($q, $i, &quot;URL&quot;);<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#008000">// Generate the code to create a command</span><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; echo &quot;nc=<a href="../../functions/addrem/dmbAPI_addCommand.htm">dmbAPI_addCommand</a>('Group001', '&quot;.addslashes($wname).&quot;', &quot;.($i&lt;$t-1?&quot;true&quot;:&quot;false&quot;).&quot;);\n&quot;;<br>
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:#008000">// Generate the code to set the new command's URL</span><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; echo &quot;<a href="../../functions/events/dmbAPI_setOnClick.htm">dmbAPI_setOnClick</a>(nc, '$url', '_blank', 'false');\n&quot;;<br>
<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; $i++;<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; }<br><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span style="color:#008000">// Close the connection to the MySQL server</span><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; mysql_close();<br>&nbsp;&nbsp;&nbsp; ?&gt;<br>&lt;/script&gt;</font></td></tr></table></center></div><p align="center"><form><p align="center"><font size="1" face="Tahoma">Click the Refresh button to refresh the page and rebuild the menu with 10 different entries from the database</font><br><input type="button" value="Refresh" name="btnRefresh" onClick="location.reload()"></p></p></form></p></body></html>